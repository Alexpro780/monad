# Monad Overview

Monad is a next-generation Layer 1 blockchain focused on scalability, parallel execution, and EVM compatibility.
This repo helps developers get started building on Monad quickly.
