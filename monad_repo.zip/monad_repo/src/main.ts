console.log("Welcome to Monad Project Template!");
console.log("Start building scalable, EVM-compatible applications on Monad.");
